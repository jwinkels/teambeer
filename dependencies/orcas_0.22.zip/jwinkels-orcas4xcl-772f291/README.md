# orcas4xcl
orcas configs for xcl
